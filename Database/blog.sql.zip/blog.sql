--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `user`, `pass`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user`, `title`, `content`, `date`) VALUES
(1, 'ansh@gmail.com', 'Date Updation Automation', 'Now the date and time will be automatic!', '2016-12-05 14:52:10');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` char(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL,
  `mobile` bigint(11) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `hobbies` varchar(40) NOT NULL,
  `image` varchar(40) NOT NULL,
  `dob` datetime NOT NULL,
  `regid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `mobile`, `gender`, `hobbies`, `image`, `dob`, `regid`) VALUES
(7, 'aman', 'aman@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 8787878, 'm', 'reading', '', '1965-09-15 00:00:00', 410),
(8, 'sarah', 'sara@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 878787, 'f', 'reading,singing', 'Lighthouse.jpg', '1966-09-15 00:00:00', 410),
(11, 'Ansh', 'ansh@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 9838119600, 'm', 'reading,singing,playing', 'Lighthouse.jpg', '1965-10-17 00:00:00', 410),
(12, 'Saraansh', 'sara@ansh.com', 'e19d5cd5af0378da05f63f891c7467af', 9838119600, 'm', 'reading,singing', 'person.jpg', '1997-05-06 00:00:00', 2147483647),
(13, 'Vasvi', 'vasvi@blogit.com', '5fc936ecbc229cd09c9aed8649ae1ece', 12345, 'f', 'singing', 'Koala.jpg', '1997-06-05 00:00:00', 2147483647),
(14, 'Smriti', 'smritimittal05@gmail.com', 'e19d5cd5af0378da05f63f891c7467af', 98298, 'm', 'reading,playing', 'Koala.jpg', '1997-05-01 00:00:00', 2147483647),
(15, 'Emin', 'emin@blogit.com', '444ab817c443ac989a845af2a0caf6f8', 7777, 'm', 'singing,playing', 'Lighthouse.jpg', '1995-02-09 00:00:00', 2147483647),
(16, 'Khandu', 'khandu@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 9898, 'm', 'reading', 'Desert.jpg', '1967-11-16 00:00:00', 2147483647),
(17, 'Shashi', 'shashwat@gmail.com', 'f2b01e630ddbd88f60bcab3f6f7ac379', 8791495808, 'm', 'singing', 'Koala.jpg', '1997-10-13 00:00:00', 2147483647),
(18, 'Runnu', 'runnu@blogit.com', 'e86bfaf8f1a63d17f76c09fbf8cae5f0', 9838119600, 'm', 'reading,singing,playing', 'Desert.jpg', '1967-09-14 00:00:00', 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);
ALTER TABLE `user` ADD FULLTEXT KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
